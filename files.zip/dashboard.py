"""
CSV Analytics Dashboard - single-file version for use inside your project.

Run:   streamlit run dashboard.py
Needs: pip install streamlit pandas numpy plotly

Edit the CONFIG block below to adapt it to your project
(title, sample file, number of auto filters, accent text).
"""
import os

# ====================== CONFIG (edit for your project) ======================
APP_TITLE = "CSV Analytics Dashboard"
APP_ICON = "📊"
SAMPLE_CSV = "sample_data.csv"   # set to None to hide the "Use sample data" option
MAX_CAT_FILTERS = 5              # max auto-generated category filters
MAX_NUM_FILTERS = 3              # max auto-generated numeric sliders
MAX_CAT_UNIQUE = 30              # only make a filter if a column has <= this many unique values
# ============================================================================
import io
import warnings
import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px

warnings.filterwarnings("ignore")

st.set_page_config(page_title=APP_TITLE, page_icon=APP_ICON, layout="wide")

st.markdown("""
<style>
.block-container {padding-top: 1.5rem;}
div[data-testid="stMetric"] {
    background: #f6f8fb; border: 1px solid #e3e8ef; padding: 14px 16px; border-radius: 10px;
}
@media (prefers-color-scheme: dark) {
    div[data-testid="stMetric"] {background: #1c2230; border-color: #2c3547;}
}
</style>
""", unsafe_allow_html=True)


# ---------- Data loading ----------
@st.cache_data(show_spinner=False)
def load_csv(file_bytes: bytes) -> pd.DataFrame:
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            return pd.read_csv(io.BytesIO(file_bytes), encoding=enc, sep=None, engine="python")
        except Exception:
            continue
    raise ValueError("Could not read this file as CSV.")


def prepare(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    for c in df.columns:
        if df[c].dtype == object:
            parsed = pd.to_datetime(df[c], errors="coerce")
            if parsed.notna().mean() > 0.8:
                df[c] = parsed
    return df


def column_types(df):
    num = df.select_dtypes(include=np.number).columns.tolist()
    dt = df.select_dtypes(include=["datetime", "datetimetz"]).columns.tolist()
    cat = [c for c in df.columns if c not in num + dt]
    return num, cat, dt


# ---------- Sidebar ----------
st.sidebar.title(f"{APP_ICON} {APP_TITLE}")
uploaded = st.sidebar.file_uploader("Insert your CSV file", type=["csv", "txt"])
use_sample = (st.sidebar.checkbox("Use sample data", value=False)
              if SAMPLE_CSV and os.path.exists(SAMPLE_CSV) else False)

if uploaded is not None:
    raw = load_csv(uploaded.getvalue())
    source = uploaded.name
elif use_sample:
    raw = pd.read_csv(SAMPLE_CSV)
    source = SAMPLE_CSV
else:
    st.title(f"{APP_ICON} {APP_TITLE}")
    st.info("👈 Click **Browse files** in the sidebar to insert your CSV file, or tick *Use sample data*.")
    st.stop()

df = prepare(raw)
num_cols, cat_cols, dt_cols = column_types(df)

# ---------- Filters ----------
st.sidebar.markdown("---")
st.sidebar.subheader("Filters")
filtered = df.copy()

for c in [c for c in cat_cols if df[c].nunique() <= MAX_CAT_UNIQUE][:MAX_CAT_FILTERS]:
    opts = sorted(df[c].dropna().astype(str).unique())
    sel = st.sidebar.multiselect(c, opts)
    if sel:
        filtered = filtered[filtered[c].astype(str).isin(sel)]

for c in num_cols[:MAX_NUM_FILTERS]:
    lo, hi = float(df[c].min()), float(df[c].max())
    if lo < hi:
        r = st.sidebar.slider(c, lo, hi, (lo, hi))
        filtered = filtered[filtered[c].between(*r)]

for c in dt_cols[:1]:
    lo, hi = df[c].min().date(), df[c].max().date()
    if lo < hi:
        r = st.sidebar.date_input(c, (lo, hi), min_value=lo, max_value=hi)
        if isinstance(r, tuple) and len(r) == 2:
            filtered = filtered[(filtered[c].dt.date >= r[0]) & (filtered[c].dt.date <= r[1])]

# ---------- Header & KPIs ----------
st.title(f"{APP_ICON} {APP_TITLE}")
st.caption(f"Source: **{source}**  |  Showing {len(filtered):,} of {len(df):,} rows")

k1, k2, k3, k4 = st.columns(4)
k1.metric("Rows", f"{len(filtered):,}")
k2.metric("Columns", f"{filtered.shape[1]}")
k3.metric("Numeric columns", len(num_cols))
k4.metric("Missing values", f"{int(filtered.isna().sum().sum()):,}")

if filtered.empty:
    st.warning("No rows match the current filters.")
    st.stop()

tab1, tab2, tab3, tab4, tab5 = st.tabs(
    ["Overview", "Chart Builder", "Correlation", "Data Quality", "Data Table"]
)

# ---------- Overview ----------
with tab1:
    st.subheader("Summary statistics")
    if num_cols:
        st.dataframe(filtered[num_cols].describe().T.round(2), use_container_width=True)
    else:
        st.write("No numeric columns found.")

    c1, c2 = st.columns(2)
    if num_cols:
        with c1:
            col = st.selectbox("Distribution of", num_cols, key="ov_num")
            fig = px.histogram(filtered, x=col, nbins=30, marginal="box", template="plotly_white")
            st.plotly_chart(fig, use_container_width=True)
    if cat_cols:
        with c2:
            col = st.selectbox("Top categories in", cat_cols, key="ov_cat")
            vc = filtered[col].astype(str).value_counts().head(10).reset_index()
            vc.columns = [col, "count"]
            fig = px.bar(vc, x="count", y=col, orientation="h", template="plotly_white")
            fig.update_layout(yaxis={"categoryorder": "total ascending"})
            st.plotly_chart(fig, use_container_width=True)

# ---------- Chart builder ----------
with tab2:
    st.subheader("Build your own chart")
    kind = st.selectbox("Chart type", ["Bar (aggregate)", "Line", "Scatter", "Box", "Pie", "Histogram"])
    all_cols = filtered.columns.tolist()
    fig = None
    try:
        if kind == "Bar (aggregate)" and cat_cols and num_cols:
            a, b, c = st.columns(3)
            x = a.selectbox("Group by", cat_cols)
            y = b.selectbox("Value", num_cols)
            agg = c.selectbox("Aggregation", ["sum", "mean", "median", "count", "max", "min"])
            g = filtered.groupby(x)[y].agg(agg).reset_index().sort_values(y, ascending=False).head(25)
            fig = px.bar(g, x=x, y=y, template="plotly_white")
        elif kind == "Line":
            a, b = st.columns(2)
            x = a.selectbox("X axis", dt_cols + num_cols + cat_cols)
            y = b.selectbox("Y axis", num_cols)
            fig = px.line(filtered.sort_values(x), x=x, y=y, template="plotly_white")
        elif kind == "Scatter" and len(num_cols) >= 2:
            a, b, c = st.columns(3)
            x = a.selectbox("X", num_cols)
            y = b.selectbox("Y", num_cols, index=1)
            color = c.selectbox("Color by", [None] + cat_cols)
            fig = px.scatter(filtered, x=x, y=y, color=color, template="plotly_white", opacity=0.75)
        elif kind == "Box" and num_cols:
            a, b = st.columns(2)
            y = a.selectbox("Value", num_cols)
            x = b.selectbox("Group by", [None] + cat_cols)
            fig = px.box(filtered, x=x, y=y, template="plotly_white")
        elif kind == "Pie" and cat_cols:
            a, b = st.columns(2)
            names = a.selectbox("Categories", cat_cols)
            values = b.selectbox("Values (blank = count)", [None] + num_cols)
            if values:
                g = filtered.groupby(names)[values].sum().reset_index().nlargest(10, values)
                fig = px.pie(g, names=names, values=values, hole=0.4)
            else:
                g = filtered[names].astype(str).value_counts().head(10).reset_index()
                g.columns = [names, "count"]
                fig = px.pie(g, names=names, values="count", hole=0.4)
        elif kind == "Histogram" and num_cols:
            x = st.selectbox("Column", num_cols)
            fig = px.histogram(filtered, x=x, nbins=30, template="plotly_white")
        if fig is not None:
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("This chart type needs column types your file doesn't have.")
    except Exception as e:
        st.error(f"Could not draw chart: {e}")

# ---------- Correlation ----------
with tab3:
    if len(num_cols) >= 2:
        corr = filtered[num_cols].corr().round(2)
        fig = px.imshow(corr, text_auto=True, color_continuous_scale="RdBu_r",
                        zmin=-1, zmax=1, aspect="auto")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Need at least two numeric columns.")

# ---------- Data quality ----------
with tab4:
    q = pd.DataFrame({
        "dtype": filtered.dtypes.astype(str),
        "missing": filtered.isna().sum(),
        "missing %": (filtered.isna().mean() * 100).round(1),
        "unique": filtered.nunique(),
    })
    st.dataframe(q, use_container_width=True)
    st.write(f"Duplicate rows: **{int(filtered.duplicated().sum()):,}**")

# ---------- Data table ----------
with tab5:
    st.dataframe(filtered, use_container_width=True, height=450)
    st.download_button("⬇ Download filtered CSV", filtered.to_csv(index=False).encode("utf-8"),
                       file_name="filtered_data.csv", mime="text/csv")
